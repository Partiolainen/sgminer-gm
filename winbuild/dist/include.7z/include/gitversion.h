#define USE_GIT_VERSION 1 
#define GIT_VERSION "5.5.5-9-g45d8a" 
